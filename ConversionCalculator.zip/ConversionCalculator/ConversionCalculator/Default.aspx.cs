﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ConversionCalculator
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void PintsRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            CalculateCups(2.0, "pints");
        }

        

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
        
        private void CalculateCups(double MeasureToCupRatio, string MeasureName)
        {
            if (TextBox1.Text.Trim().Length == 0)
                return;

            double quantity = 0.0;
            if (!Double.TryParse(TextBox1.Text, out quantity))
                return;

            double cups = quantity * MeasureToCupRatio;

            

            ResultLabel.Text = String.Format("{0:N2} {1} is equal to {2:N2} cups.", quantity, MeasureName, cups);


        }

        protected void CupsRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            CalculateCups(1.0, "cups");
        }

        protected void QuartsRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            CalculateCups(4.0, "quarts");
        }

        protected void GallonsRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            CalculateCups(16.0, "gallons");
        }
    }
}